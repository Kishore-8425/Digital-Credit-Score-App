Digital Credit Score App

A fintech web application that analyzes business transaction data to generate a digital credit score and predict loan eligibility for small retailers and shop owners.

Features

Business Credit Score Dashboard
Sales & Transaction Analytics
Loan Eligibility Prediction
EMI Planner
Repayment Reminders
Financial Health Insights



 Purpose

Small retailers often lack access to formal credit due to missing financial records.  
This application helps evaluate their financial behavior digitally and provides insights into their creditworthiness.


Installation

```bash
git clone https://github.com/your-username/digital-credit-score-app.git
cd digital-credit-score-app
npm install
npm run dev
